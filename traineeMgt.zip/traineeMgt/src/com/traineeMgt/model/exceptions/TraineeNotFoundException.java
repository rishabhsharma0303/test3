package com.traineeMgt.model.exceptions;
public class TraineeNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 4194505128085654190L;

	public TraineeNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}