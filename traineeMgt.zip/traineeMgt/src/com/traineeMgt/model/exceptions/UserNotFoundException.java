package com.traineeMgt.model.exceptions;

public class UserNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 4198505128085654190L;

	public UserNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}