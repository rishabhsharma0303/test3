package com.traineeMgt.model.service;

import com.traineeMgt.model.dao.user.User;
import com.traineeMgt.model.dao.user.UserDao;
import com.traineeMgt.model.dao.user.UserDaoImpl;

public class UserServiceImpl implements UserService{
	private UserDao userDao;
	
	public UserServiceImpl() {
		userDao=new UserDaoImpl();
	}

	

	
	@Override
	public void addUser(User user) {
		userDao.addUser(user);
	}

	@Override
	public User getUser(String username, String password) {
		// TODO Auto-generated method stub
		return userDao.getUser(username, password);
	}

}