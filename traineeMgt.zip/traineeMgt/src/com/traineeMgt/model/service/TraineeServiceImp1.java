package com.traineeMgt.model.service;

import java.util.List;

import com.traineeMgt.model.dao.Trainee;
import com.traineeMgt.model.dao.TraineeDao;
import com.traineeMgt.model.dao.TraineeDaoImp1;

public class TraineeServiceImp1 implements TraineeService{
private TraineeDao traineeDao;
	
	public TraineeServiceImp1() {
		traineeDao=new TraineeDaoImp1();
		
	}

	@Override
	public List<Trainee> getAllTrainee() {
		// TODO Auto-generated method stub
		return traineeDao.getAllTrainee();
	}

	@Override
	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		traineeDao.addTrainee(trainee);
	}
}
